module adsof {
	exports generics;
	exports test;
}