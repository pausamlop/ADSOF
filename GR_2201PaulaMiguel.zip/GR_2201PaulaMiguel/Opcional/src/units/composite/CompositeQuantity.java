package units.composite;

public class CompositeQuantity {

    private ArrayList<Quantity> quantity;


    public CompositeQuantity(IPhysicalUnit a, IPhysicalUnit b) {

        this.left = left;
        this.right = right;
    }


}